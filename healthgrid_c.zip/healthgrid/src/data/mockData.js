// ALL DATA HERE IS SYNTHETIC / DEMO. Coordinates are fictional placements around a demo city.
const B=(g,e,p,m,i)=>({General:g,Emergency:e,Pediatric:p,Maternity:m,ICU:i});
const mk=(id,name,type,area,lat,lng,pop,dens,avg,today,beds,staff)=>({id,name,type,area,lat,lng,pop,dens,avg,today,beds,staff});
const base=[
mk('dharavi','PHC Dharavi','PHC','Dharavi',19.0433,72.8553,145000,'Very High',620,784,B([20,18],[4,4],[8,5],[8,6],[2,2]),78),
mk('kurla','PHC Kurla','PHC','Kurla',19.0490,72.8670,98000,'High',480,430,B([16,12],[6,2],[8,4],[6,3],[2,1]),92),
mk('sion','PHC Sion','PHC','Sion',19.0390,72.8619,88000,'High',410,525,B([14,12],[4,4],[6,4],[6,4],[0,0]),85),
mk('andheri','PHC Andheri East','PHC','Andheri East',19.1136,72.8697,120000,'High',520,540,B([18,15],[4,3],[8,5],[8,5],[2,1]),88),
mk('bhandup','PHC Bhandup','PHC','Bhandup',19.1450,72.9370,54000,'Medium',260,190,B([16,6],[4,1],[8,2],[6,2],[0,0]),95),
mk('govandi','PHC Govandi','PHC','Govandi',19.0550,72.9150,110000,'Very High',470,560,B([14,13],[3,3],[6,5],[6,5],[0,0]),72),
mk('mankhurd','PHC Mankhurd','PHC','Mankhurd',19.0480,72.9320,76000,'Medium',300,280,B([12,7],[3,1],[6,3],[6,2],[0,0]),90),
mk('mulund','PHC Mulund','PHC','Mulund',19.1720,72.9560,47000,'Low',210,150,B([14,5],[4,1],[6,1],[6,2],[0,0]),96),
mk('vikhroli','PHC Vikhroli','PHC','Vikhroli',19.1100,72.9250,62000,'Medium',280,300,B([14,9],[4,2],[6,3],[6,3],[0,0]),86),
mk('dhc','District Hospital Central','District Hospital','Central',19.0820,72.8800,310000,'High',1400,1480,B([90,62],[14,7],[24,14],[24,15],[12,8]),90),
mk('chce','Community Health Centre East','CHC','East',19.0700,72.9000,180000,'High',760,700,B([40,28],[8,5],[12,7],[12,8],[4,2]),87),
mk('chcw','Community Health Centre West','CHC','West',19.0650,72.8420,160000,'Medium',640,610,B([36,22],[8,4],[12,6],[10,5],[4,2]),91)];

// [category, product, generic, strength, form, base daily use per 100k pop]
const MED=[['Analgesics & Antipyretics','Paracetamol','Paracetamol','500 mg','Tablet',180],['Analgesics & Antipyretics','Ibuprofen','Ibuprofen','400 mg','Tablet',70],
['Antibiotics','Amoxicillin','Amoxicillin','500 mg','Capsule',110],['Antibiotics','Azithromycin','Azithromycin','500 mg','Tablet',45],
['Antidiabetics','Metformin','Metformin','500 mg','Tablet',140],['Antidiabetics','Insulin Regular','Human Insulin','40 IU/mL','Injection',18],
['Antihypertensives','Amlodipine','Amlodipine','5 mg','Tablet',120],['Respiratory','Salbutamol','Salbutamol','100 mcg','Inhaler',22],
['ORS & Rehydration','ORS','Oral Rehydration Salts','21 g','Sachet',95],['IV Fluids','Normal Saline','Sodium Chloride','0.9% / 500 mL','IV Bag',25],
['Emergency Medicines','Adrenaline','Adrenaline','1 mg/mL','Injection',4],['Antiseptics','Povidone Iodine','Povidone Iodine','5%','Solution',8],
['Medical Consumables','Surgical Gloves','Nitrile Gloves','Medium','Box',12]];
const DAYS_OVERRIDE={'dharavi|Amoxicillin':2.4,'kurla|Insulin Regular':1.8,'andheri|Insulin Regular':2.1,'govandi|ORS':3.1,'bhandup|Amoxicillin':14,'mulund|Amoxicillin':18,'dharavi|Paracetamol':6.5};
const riskOf=d=>d<3?'CRITICAL':d<7?'HIGH':d<12?'MEDIUM':'LOW';
const addDays=n=>{const d=new Date('2026-09-30');d.setDate(d.getDate()+Math.round(n));return d.toISOString().slice(0,10)};
export const medicines=[];
base.forEach((f,fi)=>MED.forEach((m,mi)=>{
  const days=DAYS_OVERRIDE[f.id+'|'+m[1]]??5+((fi*7+mi*5)%19)+0.5;
  const daily=Math.max(2,Math.round(m[5]*f.pop/100000*(f.type==='PHC'?1:0.8)));
  medicines.push({id:`${f.id}-m${mi}`,fid:f.id,category:m[0],name:m[1],generic:m[2],strength:m[3],form:m[4],daily,days:+days.toFixed(1),
    stock:Math.round(daily*days),min:Math.round(daily*5),expiry:addDays(60+((fi*mi*13)%300)),risk:riskOf(days)});}));

const EQ=[['Patient Monitoring','Pulse Oximeter'],['Patient Monitoring','Patient Monitor'],['Diagnostic','ECG Machine'],['Diagnostic','Glucometer'],
['Emergency','Defibrillator'],['Emergency','Suction Machine'],['Respiratory','Oxygen Concentrator'],['Respiratory','Nebulizer'],['Respiratory','Ventilator'],
['Imaging','Ultrasound Machine'],['Imaging','X-Ray Machine'],['Laboratory','Hemoglobin Analyzer'],['Laboratory','Autoclave'],['General','Blood Pressure Monitor']];
const HEAVY=['Ventilator','Ultrasound Machine','X-Ray Machine'];
// override: [total, maintenance]
const EQ_OVERRIDE={'dharavi|Defibrillator':[1,1],'dharavi|Oxygen Concentrator':[4,1],'sion|ECG Machine':[2,1],'kurla|Oxygen Concentrator':[5,1],'kurla|Ventilator':[1,0],'kurla|Defibrillator':[2,0]};
export const equipment=[];
base.forEach((f,fi)=>EQ.forEach((e,ei)=>{
  if(HEAVY.includes(e[1])&&f.type==='PHC'&&!(f.id==='kurla'&&e[1]==='Ventilator'))return;
  let total=1+((fi+ei)%4),maint=(fi*3+ei*2)%5===0?1:0,un=(fi+ei*3)%11===0?1:0;
  const o=EQ_OVERRIDE[f.id+'|'+e[1]];if(o){[total,maint]=o;un=0}
  const oper=Math.max(0,total-maint-un);
  equipment.push({id:`${f.id}-e${ei}`,fid:f.id,category:e[0],name:e[1],total,oper,maint,unavail:total-oper-maint,
    last:addDays(-(10+((fi+ei)*9)%120)),next:f.id==='sion'&&e[1]==='ECG Machine'?addDays(3):addDays(5+((fi*ei*7)%150)),
    status:oper===0?'Unavailable':oper<total?'Partial':'Available'});}));

export const facilities=base.map(f=>{
  const ms=medicines.filter(m=>m.fid===f.id),es=equipment.filter(e=>e.fid===f.id);
  const med=Math.round(100*ms.filter(m=>m.days>=7).length/ms.length);
  const eq=Math.round(100*es.reduce((a,e)=>a+e.oper,0)/es.reduce((a,e)=>a+e.total,0));
  const emFull=f.beds.Emergency[0]-f.beds.Emergency[1]===0;
  const score=(emFull?2:0)+(med<70?2:med<85?1:0)+(eq<80?1:0)+(f.today/f.avg>1.2?1:0)+(f.staff<80?1:0);
  return {...f,med,eq,risk:score>=4?'CRITICAL':score===3?'HIGH':score===2?'MEDIUM':'LOW'};
});

export const alerts=[
{id:'a1',sev:'CRITICAL',type:'Medicine shortage',fid:'andheri',text:'Insulin stock projected to run out in 2 days'},
{id:'a2',sev:'CRITICAL',type:'Medicine shortage',fid:'kurla',text:'Insulin stock may fall below minimum level within 2 days'},
{id:'a3',sev:'HIGH',type:'Bed shortage',fid:'dharavi',text:'Emergency beds are 100% occupied'},
{id:'a4',sev:'CRITICAL',type:'Equipment failure',fid:'dharavi',text:'Defibrillator unavailable (under maintenance)'},
{id:'a5',sev:'MEDIUM',type:'High patient footfall',fid:'sion',text:'Patient footfall 28% above normal'},
{id:'a6',sev:'MEDIUM',type:'Maintenance due',fid:'sion',text:'ECG machine due for maintenance in 3 days'},
{id:'a7',sev:'MEDIUM',type:'Staff shortage',fid:'govandi',text:'Staff attendance at 72% today'}];
export const SEV_ORDER={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};
