import {useEffect,useRef} from 'react';
import L from 'leaflet';import 'leaflet/dist/leaflet.css';
const COLOR={LOW:'#16a34a',MEDIUM:'#eab308',HIGH:'#dc2626',CRITICAL:'#dc2626'};
const DENS={'Very High':0.35,High:0.25,Medium:0.15,Low:0.08};
export default function FacilityMap({items,onOpen,height=380,focus=[],density=false}){
  const el=useRef(),map=useRef(),layer=useRef(),cb=useRef(onOpen);cb.current=onOpen;
  useEffect(()=>{
    map.current=L.map(el.current).setView([19.08,72.9],12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map.current);
    layer.current=L.layerGroup().addTo(map.current);
    map.current.on('popupopen',e=>{const b=e.popup.getElement()?.querySelector('.hg-open');if(b)b.onclick=()=>cb.current&&cb.current(b.dataset.id)});
    return()=>map.current.remove();
  },[]);
  useEffect(()=>{
    layer.current.clearLayers();
    items.forEach(f=>{
      const foc=focus.includes(f.id),c=COLOR[f.risk];
      if(density)L.circle([f.lat,f.lng],{radius:f.pop/145000*1400,color:'#7c3aed',weight:0,fillOpacity:DENS[f.dens]}).addTo(layer.current);
      const bs=Object.values(f.beds),tot=bs.reduce((a,b)=>a+b[0],0),occ=bs.reduce((a,b)=>a+b[1],0);
      L.circleMarker([f.lat,f.lng],{radius:foc?13:f.type==='PHC'?8:11,color:foc?'#0f172a':'#fff',weight:foc?3:2,fillColor:c,fillOpacity:.95})
        .bindPopup(`<b>${f.name}</b><br/>${f.type} • Risk: <b>${f.risk}</b><br/>Beds available: ${tot-occ}/${tot}<br/>Medicine health: ${f.med}% • Equipment: ${f.eq}%<br/>Today's patients: ${f.today}<br/>Population served: ${f.pop.toLocaleString()}<br/>${onOpen?`<button class="hg-open" data-id="${f.id}" style="margin-top:6px;background:#0d9488;color:#fff;border-radius:8px;padding:3px 10px">Open details</button>`:''}`)
        .bindTooltip(f.name).addTo(layer.current);
    });
    if(items.length>1&&focus.length)map.current.fitBounds(L.latLngBounds(items.map(f=>[f.lat,f.lng])),{padding:[40,40]});
    else if(items.length===1)map.current.setView([items[0].lat,items[0].lng],14);
  },[items,focus,density]);
  return <div ref={el} style={{height}} className="w-full z-0"/>;
}
