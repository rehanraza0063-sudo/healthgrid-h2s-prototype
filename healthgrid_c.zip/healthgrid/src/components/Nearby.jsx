import {MapPin,Clock,BedDouble} from 'lucide-react';
import {Btn,Card,Empty} from './ui';
import FacilityMap from './FacilityMap';
import {oxy} from '../services/resources';
// Shared result list + map used by beds, equipment, medicines and Resource Finder.
export function ResultCards({results,from,onView,action,label='available'}){
  if(!results.length)return <Empty text="No facilities found."/>;
  return <div className="space-y-2">{results.map(r=>(
    <div key={r.f.id} className={`rounded-xl border p-3 flex items-center justify-between gap-2 ${r.ok?'border-emerald-200 bg-emerald-50/50':'border-slate-200 bg-slate-50 opacity-70'}`}>
      <div><button onClick={()=>onView(r.f.id)} className="font-semibold hover:underline text-left">{r.f.name}</button>
        <div className="text-xs text-slate-500 flex gap-3 mt-0.5"><span className="flex items-center gap-1"><MapPin size={12}/>{r.km} km</span><span className="flex items-center gap-1"><Clock size={12}/>ETA {r.eta} min</span></div>
        <div className="text-sm mt-1">{r.detail}{!r.ok&&<span className="text-red-600 font-medium"> — not {label}</span>}</div></div>
      {r.ok&&action&&action(r)}</div>))}</div>;
}
export function NearbyBeds({f,type,ctx,results}){
  const res=results.filter(r=>r.ok).slice(0,4),top=res[0];
  return <Card title={`Nearby ${type} beds for ${f.name}`} className="border-teal-300">
    {top&&<div className="text-sm mb-3 bg-teal-50 rounded-lg p-2">Best match: <b>{top.f.name}</b> ({top.km} km) • {top.count} {type.toLowerCase()} bed(s) • {oxy(top.f)} oxygen concentrator(s) operational • medicine stock health {top.f.med}%</div>}
    <div className="grid lg:grid-cols-2 gap-4"><ResultCards results={res} onView={ctx.open} label="available"
      action={r=><Btn onClick={()=>ctx.book({fid:r.f.id,type,origin:f.id})}><BedDouble size={14} className="inline mr-1"/>Reserve Bed</Btn>}/>
      <FacilityMap items={[f,...res.map(r=>r.f)]} focus={[f.id,...res.map(r=>r.f.id)]} height={260} onOpen={ctx.open}/></div></Card>;
}
