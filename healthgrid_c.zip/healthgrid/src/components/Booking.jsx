import {useState} from 'react';
import {CheckCircle2} from 'lucide-react';
import {Modal,Btn,Select} from './ui';
import {fac,CATALOG} from '../services/resources';
export default function BookingModal({req,onClose,onBook}){
  const [f,setF]=useState({ref:'PT-'+Math.floor(1000+Math.random()*9000),bed:req.type||'Emergency',eta:'15 min',emergency:true});
  const [done,setDone]=useState(null);const target=fac(req.fid);
  const submit=()=>setDone(onBook({...f,fid:req.fid,origin:req.origin}));
  const Field=({l,children})=><label className="block text-sm mb-3"><span className="text-slate-500">{l}</span>{children}</label>;
  return <Modal title={done?'Bed Reserved':'Reserve Bed'} onClose={onClose}>
    {done?<div className="text-sm space-y-2"><div className="flex items-center gap-2 text-emerald-600 font-semibold"><CheckCircle2/>✓ Bed Reserved</div>
      <div>Reservation ID: <b>{done.id}</b></div><div>Facility: <b>{target.name}</b></div><div>Bed Type: <b>{done.bed}</b></div><div>Status: <b>Reserved</b></div>
      <p className="text-xs bg-amber-50 text-amber-700 rounded-lg p-2">Prototype Simulation — Not a real medical booking.</p><Btn onClick={onClose}>Done</Btn></div>
    :<>
      <Field l="Patient Reference ID"><input className="mt-1 w-full border rounded-lg px-2 py-1.5" value={f.ref} onChange={e=>setF({...f,ref:e.target.value})}/></Field>
      <Field l="Facility"><div className="mt-1 font-medium">{target.name}</div></Field>
      <Field l="Bed Type"><div className="mt-1"><Select label="Bed type" value={f.bed} onChange={v=>setF({...f,bed:v})} options={CATALOG.Bed}/></div></Field>
      <Field l="Estimated Arrival"><div className="mt-1"><Select label="ETA" value={f.eta} onChange={v=>setF({...f,eta:v})} options={['10 min','15 min','30 min','1 hour']}/></div></Field>
      <label className="flex items-center gap-2 text-sm mb-4"><input type="checkbox" checked={f.emergency} onChange={e=>setF({...f,emergency:e.target.checked})}/>Emergency case</label>
      <p className="text-xs text-amber-700 mb-3">Prototype Simulation — Not a real medical booking.</p>
      <Btn onClick={submit} disabled={!f.ref.trim()}>Reserve Bed</Btn></>}
  </Modal>;
}
