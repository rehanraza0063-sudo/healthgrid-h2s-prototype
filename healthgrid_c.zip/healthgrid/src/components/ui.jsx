import {X} from 'lucide-react';
const RC={LOW:'bg-emerald-100 text-emerald-700',MEDIUM:'bg-amber-100 text-amber-700',HIGH:'bg-orange-100 text-orange-700',CRITICAL:'bg-red-100 text-red-700'};
export const RiskBadge=({r})=><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${RC[r]||'bg-slate-100 text-slate-600'}`}>{r}</span>;
export const Card=({title,right,children,className=''})=>(
  <section className={`bg-white/80 backdrop-blur rounded-2xl border border-slate-200/70 shadow-sm p-4 ${className}`}>
    {(title||right)&&<div className="flex items-center justify-between mb-3 gap-2"><h3 className="font-semibold text-slate-800">{title}</h3>{right}</div>}{children}</section>);
const TONES={teal:'bg-teal-50 text-teal-600',red:'bg-red-50 text-red-600',blue:'bg-blue-50 text-blue-600',amber:'bg-amber-50 text-amber-600'};
export const Kpi=({icon:I,label,value,tone='teal',onClick})=>(
  <button onClick={onClick} className="text-left bg-white/80 rounded-2xl border border-slate-200/70 shadow-sm p-4 hover:shadow-md hover:-translate-y-0.5 transition">
    <span className={`inline-flex p-2 rounded-xl ${TONES[tone]}`}><I size={18}/></span>
    <div className="text-2xl font-bold mt-2">{value}</div><div className="text-xs text-slate-500">{label}</div></button>);
export const Btn=({variant='primary',className='',...p})=>(
  <button {...p} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition disabled:opacity-50 ${variant==='primary'?'bg-teal-600 text-white hover:bg-teal-700':variant==='danger'?'bg-red-600 text-white hover:bg-red-700':'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'} ${className}`}/>);
export const Modal=({title,onClose,children})=>(
  <div role="dialog" aria-modal="true" className="fixed inset-0 z-[2000] bg-slate-900/40 flex items-center justify-center p-4" onClick={onClose}>
    <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-5" onClick={e=>e.stopPropagation()}>
      <div className="flex justify-between items-center mb-3"><h3 className="font-semibold text-lg">{title}</h3><button aria-label="Close" onClick={onClose}><X size={18}/></button></div>{children}</div></div>);
export const Progress=({v,max=100,tone})=>{const p=max?v/max*100:0;
  return <div className="h-2 rounded-full bg-slate-100"><div className={`h-2 rounded-full ${tone||(p>=95?'bg-red-500':p>=80?'bg-amber-500':'bg-teal-500')}`} style={{width:`${Math.min(100,p)}%`}}/></div>};
export const Empty=({text})=><div className="text-center text-sm text-slate-400 py-8">{text}</div>;
export const Select=({value,onChange,options,label})=>(
  <select aria-label={label} value={value} onChange={e=>onChange(e.target.value)} className="border border-slate-200 rounded-lg px-2 py-1.5 text-sm bg-white">
    {options.map(o=>Array.isArray(o)?<option key={o[0]} value={o[0]}>{o[1]}</option>:<option key={o}>{o}</option>)}</select>);
export const Tbl=({head,children})=>(
  <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-xs text-slate-500 border-b">{head.map(h=><th key={h} className="py-2 pr-3 font-medium whitespace-nowrap">{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div>);
export const Synthetic=({text='DEMO / SYNTHETIC DATA'})=><span className="text-[10px] font-bold tracking-wide px-2 py-0.5 rounded bg-slate-100 text-slate-500">{text}</span>;
