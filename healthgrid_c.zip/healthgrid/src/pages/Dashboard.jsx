import {useState,useMemo} from 'react';
import {Building2,BedDouble,Pill,Stethoscope,Bell,Users,Search,Siren} from 'lucide-react';
import {BarChart,Bar,XAxis,YAxis,Tooltip,Legend,ResponsiveContainer} from 'recharts';
import {Card,Kpi,RiskBadge,Btn,Select,Tbl,Synthetic} from '../components/ui';
import FacilityMap from '../components/FacilityMap';
import {facilities,medicines,alerts,SEV_ORDER} from '../data/mockData';
import {bedStats,avail,oxy,footfallPct} from '../services/resources';

const FILTERS={All:()=>true,Beds:f=>bedStats(f).avail/bedStats(f).total<0.25,Medicines:f=>f.med<85,Equipment:f=>f.eq<85,
  'High Risk':f=>['HIGH','CRITICAL'].includes(f.risk),'Low Stock':f=>medicines.some(m=>m.fid===f.id&&m.days<5)};
export const SevDot=({s})=><span>{s==='CRITICAL'?'🔴':s==='HIGH'?'🟠':'🟡'}</span>;
export function AlertCard({a,ctx,resolved}){
  const f=facilities.find(x=>x.id===a.fid);
  return <button onClick={()=>ctx.open(a.fid)} className={`w-full text-left rounded-xl border p-3 hover:shadow transition ${resolved?'bg-emerald-50 border-emerald-200':'bg-white border-slate-200'}`}>
    <div className="flex justify-between text-xs text-slate-500"><span>{resolved?'✅ RESOLVED':<><SevDot s={a.sev}/> {a.sev} • {a.type}</>}</span></div>
    <div className="font-semibold text-sm">{f.name}</div><div className="text-sm text-slate-600">{resolved?'Emergency bed shortage resolved through nearby facility.':a.text}</div></button>;
}
export default function Dashboard({ctx}){
  const [flt,setFlt]=useState('All');
  const items=useMemo(()=>facilities.filter(FILTERS[flt]),[flt]);
  const tb=facilities.reduce((a,f)=>a+bedStats(f).total,0),ab=facilities.reduce((a,f)=>a+bedStats(f).avail,0);
  const active=alerts.filter(a=>!ctx.resolved(a)).sort((a,b)=>SEV_ORDER[a.sev]-SEV_ORDER[b.sev]);
  const chart=facilities.map(f=>({name:f.name.replace('PHC ','').replace('Community Health Centre','CHC').replace('District Hospital','DH'),Beds:Math.round(bedStats(f).avail/bedStats(f).total*100),Medicines:f.med,Equipment:f.eq}));
  return <div className="space-y-4">
    <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
      <Kpi icon={Building2} label="Total Facilities" value={facilities.length} onClick={()=>ctx.go('facilities')}/>
      <Kpi icon={BedDouble} label="Available Beds" value={`${ab} / ${tb}`} tone="blue" onClick={()=>ctx.go('beds')}/>
      <Kpi icon={Pill} label="Medicine Stock Health" value={Math.round(medicines.filter(m=>m.days>=7).length/medicines.length*100)+'%'} onClick={()=>ctx.go('medicines')}/>
      <Kpi icon={Stethoscope} label="Equipment Availability" value="91%" tone="blue" onClick={()=>ctx.go('equipment')}/>
      <Kpi icon={Bell} label="Active Alerts" value={active.length} tone="red" onClick={()=>ctx.go('alerts')}/>
      <Kpi icon={Users} label="Today's Footfall" value={facilities.reduce((a,f)=>a+f.today,0).toLocaleString()} tone="amber" onClick={()=>ctx.go('population')}/></div>
    <button onClick={()=>ctx.go('network')} className="w-full flex items-center gap-3 rounded-2xl bg-gradient-to-r from-teal-600 to-cyan-600 text-white p-4 hover:opacity-95 text-left">
      <Search/><div><div className="font-semibold">Find a Resource</div><div className="text-sm opacity-90">Beds, medicines, equipment, specialists, blood — search the whole network instantly</div></div></button>
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2" title="Facility Network Map" right={<Select label="Map filter" value={flt} onChange={setFlt} options={Object.keys(FILTERS)}/>}>
        <FacilityMap items={items} onOpen={ctx.open} height={400}/><div className="text-xs text-slate-500 mt-2">🟢 Healthy &nbsp; 🟡 Moderate risk &nbsp; 🔴 Critical • Showing {items.length} facilities</div></Card>
      <Card title="Resource Risk Monitor" right={<Btn variant="ghost" onClick={()=>ctx.go('alerts')}>All</Btn>}>
        <div className="space-y-2">{active.slice(0,5).map(a=><AlertCard key={a.id} a={a} ctx={ctx}/>)}</div></Card></div>
    <Card title="Resource Distribution (% available)" right={<Synthetic/>}><div style={{height:260}}><ResponsiveContainer><BarChart data={chart}><XAxis dataKey="name" tick={{fontSize:10}} interval={0} angle={-25} height={60} textAnchor="end"/><YAxis/><Tooltip/><Legend/>
      <Bar dataKey="Beds" fill="#0ea5e9" radius={[4,4,0,0]}/><Bar dataKey="Medicines" fill="#14b8a6" radius={[4,4,0,0]}/><Bar dataKey="Equipment" fill="#8b5cf6" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></Card></div>;
}
export function Alerts({ctx}){
  const [type,setType]=useState('All'),[sev,setSev]=useState('All');
  const types=['All',...new Set(alerts.map(a=>a.type))];
  const list=alerts.filter(a=>(type==='All'||a.type===type)&&(sev==='All'||a.sev===sev)).sort((a,b)=>SEV_ORDER[a.sev]-SEV_ORDER[b.sev]);
  return <Card title="Smart Alerts Center" right={<div className="flex gap-2"><Select label="Type" value={type} onChange={setType} options={types}/><Select label="Severity" value={sev} onChange={setSev} options={['All','CRITICAL','HIGH','MEDIUM']}/></div>}>
    <div className="grid md:grid-cols-2 gap-2">{list.map(a=><AlertCard key={a.id} a={a} ctx={ctx} resolved={ctx.resolved(a)}/>)}</div>{!list.length&&<p className="text-sm text-slate-400 text-center py-6">No alerts match.</p>}</Card>;
}
export function Population({ctx}){
  return <div className="space-y-4"><Card title="Population Density Layer" right={<Synthetic/>}>
    <FacilityMap items={facilities} density onOpen={ctx.open} height={340}/><div className="text-xs text-slate-500 mt-2">Purple circles scale with catchment population (synthetic).</div></Card>
    <Card title="Population & Demand" right={<Synthetic/>}><Tbl head={['Facility','Population Served','Density','Avg Daily','Peak Daily','Today','Trend']}>
      {facilities.map(f=>{const p=footfallPct(f);return <tr key={f.id} onClick={()=>ctx.open(f.id)} className="border-b hover:bg-teal-50/50 cursor-pointer">
        <td className="py-2 font-medium">{f.name}</td><td>{f.pop.toLocaleString()}</td><td>{f.dens}</td><td>{f.avg}</td><td>{Math.round(f.avg*1.35)}</td><td>{f.today}</td>
        <td className={p>15?'text-red-600 font-semibold':p>0?'text-amber-600':'text-emerald-600'}>{p>0?'+':''}{p}%</td></tr>})}</Tbl></Card></div>;
}
export function Emergency({ctx}){
  const crit=facilities.filter(f=>['HIGH','CRITICAL'].includes(f.risk));
  const donor=[...facilities].filter(f=>f.type==='PHC').sort((a,b)=>oxy(b)-oxy(a))[0];
  const target=[...crit].sort((a,b)=>oxy(a)-oxy(b))[0]||facilities[0];
  const calm=[...facilities].sort((a,b)=>a.today/a.avg-b.today/b.avg)[0];
  const S=({l,v})=><div className="bg-white/10 rounded-xl p-3"><div className="text-2xl font-bold">{v}</div><div className="text-xs opacity-80">{l}</div></div>;
  return <div className="space-y-4"><div className="rounded-2xl bg-gradient-to-r from-red-700 to-rose-600 text-white p-5">
    <div className="flex items-center gap-2 font-bold text-lg"><Siren/>EMERGENCY MODE — Respiratory Disease Surge <span className="text-[10px] bg-white/20 px-2 rounded">SIMULATION</span></div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4"><S l="Patient footfall" v="+35%"/><S l="Oxygen demand" v="+42%"/><S l="Emergency beds occupied" v="78%"/><S l="Facilities at high risk" v={crit.length}/></div></div>
    <div className="grid lg:grid-cols-2 gap-4"><Card title="Critical Facilities"><div className="space-y-2">{crit.map(f=><button key={f.id} onClick={()=>ctx.open(f.id)} className="w-full flex justify-between items-center border rounded-xl p-3 hover:bg-slate-50 text-left">
      <div><div className="font-semibold text-sm">{f.name}</div><div className="text-xs text-slate-500">Emergency beds free: {avail(f,'Emergency')} • O₂ concentrators: {oxy(f)} • Medicines {f.med}%</div></div><RiskBadge r={f.risk}/></button>)}</div></Card>
      <Card title="Recommended Actions (simulated)"><ol className="list-decimal ml-5 space-y-2 text-sm">
        <li>Move oxygen concentrators from <b>{donor.name}</b> → <b>{target.name}</b></li><li>Redirect non-critical patients to <b>{calm.name}</b></li>
        <li>Monitor emergency bed availability (<button className="text-teal-700 underline" onClick={()=>ctx.go('beds')}>open Beds</button>)</li>
        <li>Replenish respiratory medicine stock (<button className="text-teal-700 underline" onClick={()=>ctx.go('medicines')}>open Medicines</button>)</li></ol>
        <Btn className="mt-4" onClick={()=>ctx.toast('Emergency plan acknowledged (simulation)')}>Acknowledge plan</Btn></Card></div>
    <Card title="Available Nearby Resources"><FacilityMap items={facilities} onOpen={ctx.open} height={300}/></Card></div>;
}
