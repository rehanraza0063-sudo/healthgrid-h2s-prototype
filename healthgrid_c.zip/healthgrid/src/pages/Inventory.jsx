import {useState} from 'react';
import {ArrowRight,Sparkles} from 'lucide-react';
import {Card,RiskBadge,Btn,Select,Tbl,Empty} from '../components/ui';
import {ResultCards} from '../components/Nearby';
import FacilityMap from '../components/FacilityMap';
import {facilities,medicines,equipment} from '../data/mockData';
import {fac,find,recommendTransfer} from '../services/resources';

export function TransferCard({t,ctx}){
  return <Card title="Recommended Redistribution" className="border-teal-300"><div className="flex items-center gap-3 flex-wrap text-sm">
    <div className="rounded-xl bg-emerald-50 p-3"><b>{t.from.name}</b><div className="text-xs">{t.donorDays} days of stock</div></div>
    <div className="text-center"><ArrowRight/><div className="font-bold">{t.units} units</div></div>
    <div className="rounded-xl bg-red-50 p-3"><b>{t.to.name}</b><div className="text-xs">{t.targetDays} days of stock</div></div></div>
    <div className="mt-3 text-sm bg-slate-50 rounded-lg p-2 flex gap-2"><Sparkles size={16} className="text-teal-600 shrink-0 mt-0.5"/><div><b>AI Recommendation (simulated):</b> {t.reason}</div></div>
    <div className="flex gap-2 mt-3"><Btn onClick={()=>ctx.approveTransfer(t)}>Approve transfer (simulated)</Btn><Btn variant="ghost" onClick={()=>ctx.go('assistant')}>Ask why</Btn></div></Card>;
}
export function Medicines({ctx}){
  const [f,setF]=useState('All'),[c,setC]=useState('All'),[r,setR]=useState('All'),[d,setD]=useState('All'),[sel,setSel]=useState(null);
  const cats=['All',...new Set(medicines.map(m=>m.category))];
  const rows=medicines.filter(m=>(f==='All'||m.fid===f)&&(c==='All'||m.category===c)&&(r==='All'||m.risk===r)&&(d==='All'||m.days<=+d)
    &&(!ctx.q||(m.name+m.generic+m.category).toLowerCase().includes(ctx.q.toLowerCase()))).sort((a,b)=>a.days-b.days);
  const t=sel&&recommendTransfer(fac(sel.fid),sel.name);
  return <div className="space-y-4">
    {sel&&(t?<TransferCard t={t} ctx={ctx}/>:<Card title="Nearby stock"><Empty text={`No facility has surplus ${sel.name} right now.`}/></Card>)}
    <Card title="Medicine Inventory" right={<span className="text-xs text-slate-400">{rows.length} records • sorted by days remaining</span>}>
      <div className="flex gap-2 flex-wrap mb-3"><Select label="Facility" value={f} onChange={setF} options={[['All','All facilities'],...facilities.map(x=>[x.id,x.name])]}/>
        <Select label="Category" value={c} onChange={setC} options={cats}/><Select label="Risk" value={r} onChange={setR} options={['All','CRITICAL','HIGH','MEDIUM','LOW']}/>
        <Select label="Days remaining" value={d} onChange={setD} options={[['All','Any days left'],['3','≤ 3 days'],['7','≤ 7 days'],['14','≤ 14 days']]}/></div>
      {rows.length?<Tbl head={['Category','Product','Generic','Strength / Form','Facility','Stock','Min','Daily','Days left','Expiry','Risk','']}>
        {rows.slice(0,60).map(m=><tr key={m.id} className="border-b hover:bg-slate-50"><td className="py-1.5 text-xs">{m.category}</td><td className="font-medium">{m.name}</td><td>{m.generic}</td><td>{m.strength} • {m.form}</td>
          <td>{fac(m.fid).name}</td><td>{m.stock.toLocaleString()}</td><td>{m.min}</td><td>{m.daily}</td><td>{m.days}</td><td>{m.expiry}</td><td><RiskBadge r={m.risk}/></td>
          <td>{['CRITICAL','HIGH'].includes(m.risk)&&<Btn variant="ghost" onClick={()=>setSel(m)}>Find Nearby Stock</Btn>}</td></tr>)}</Tbl>:<Empty text="No medicines match your filters."/>}</Card></div>;
}
export function Equipment({ctx}){
  const [f,setF]=useState('All'),[c,setC]=useState('All'),[s,setS]=useState('All'),[sel,setSel]=useState(null);
  const cats=['All',...new Set(equipment.map(e=>e.category))];
  const rows=equipment.filter(e=>(f==='All'||e.fid===f)&&(c==='All'||e.category===c)&&(s==='All'||e.status===s)&&(!ctx.q||(e.name+e.category).toLowerCase().includes(ctx.q.toLowerCase())));
  const from=sel&&fac(sel.fid),res=sel?find('Equipment',sel.name,from).slice(0,4):[];
  return <div className="space-y-4">
    {sel&&<Card title={`Nearby ${sel.name} for ${from.name}`} className="border-teal-300"><div className="grid lg:grid-cols-2 gap-4"><ResultCards results={res} onView={ctx.open} label="operational"/>
      <FacilityMap items={[from,...res.filter(r=>r.ok).map(r=>r.f)]} focus={[from.id,...res.map(r=>r.f.id)]} height={240} onOpen={ctx.open}/></div></Card>}
    <Card title="Medical Equipment Inventory"><div className="flex gap-2 flex-wrap mb-3"><Select label="Facility" value={f} onChange={setF} options={[['All','All facilities'],...facilities.map(x=>[x.id,x.name])]}/>
      <Select label="Category" value={c} onChange={setC} options={cats}/><Select label="Status" value={s} onChange={setS} options={['All','Available','Partial','Unavailable']}/></div>
      {rows.length?<Tbl head={['Equipment','Category','Facility','Total','Operational','Maint.','Unavail.','Last maint.','Next maint.','Status','']}>
        {rows.slice(0,70).map(e=><tr key={e.id} className="border-b hover:bg-slate-50"><td className="py-1.5 font-medium">{e.name}</td><td>{e.category}</td><td>{fac(e.fid).name}</td><td>{e.total}</td><td>{e.oper}</td><td>{e.maint}</td><td>{e.unavail}</td><td>{e.last}</td><td>{e.next}</td>
          <td><span className={e.status==='Unavailable'?'text-red-600 font-semibold':e.status==='Partial'?'text-amber-600':'text-emerald-600'}>{e.status}</span></td>
          <td>{e.status!=='Available'&&<Btn variant="ghost" onClick={()=>setSel(e)}>Find Nearby Equipment</Btn>}</td></tr>)}</Tbl>:<Empty text="No equipment matches."/>}</Card></div>;
}
