import {useState,useRef,useEffect} from 'react';
import {Bot,Send,User} from 'lucide-react';
import {Card,Btn} from '../components/ui';
import {answer,SUGGESTED} from '../services/ai';
export default function Assistant(){
  const [msgs,setMsgs]=useState([{r:'ai',t:'Hi, I am HealthGrid Intelligence. Ask me about beds, medicines, equipment or redistribution across the demo network.'}]);
  const [q,setQ]=useState(''),[busy,setBusy]=useState(false),end=useRef();
  useEffect(()=>end.current?.scrollIntoView({behavior:'smooth'}),[msgs,busy]);
  const ask=t=>{if(!t.trim()||busy)return;setMsgs(m=>[...m,{r:'me',t}]);setQ('');setBusy(true);setTimeout(()=>{setMsgs(m=>[...m,{r:'ai',t:answer(t)}]);setBusy(false)},600)};
  return <Card title="HealthGrid Intelligence" right={<span className="text-xs text-slate-400">AI insights are generated from prototype synthetic data.</span>}>
    <div className="flex flex-wrap gap-2 mb-3">{SUGGESTED.map(s=><button key={s} onClick={()=>ask(s)} className="text-xs border border-teal-200 bg-teal-50 text-teal-800 rounded-full px-3 py-1 hover:bg-teal-100">{s}</button>)}</div>
    <div className="h-[420px] overflow-y-auto space-y-3 p-2 bg-slate-50 rounded-xl">{msgs.map((m,i)=><div key={i} className={`flex gap-2 ${m.r==='me'?'justify-end':''}`}>
      {m.r==='ai'&&<Bot className="text-teal-600 shrink-0" size={20}/>}<div className={`whitespace-pre-line text-sm rounded-2xl px-3 py-2 max-w-[85%] ${m.r==='me'?'bg-teal-600 text-white':'bg-white border'}`}>{m.t}</div>{m.r==='me'&&<User size={20} className="shrink-0 text-slate-400"/>}</div>)}
      {busy&&<div className="text-sm text-slate-400 animate-pulse">HealthGrid Intelligence is analysing…</div>}<div ref={end}/></div>
    <div className="flex gap-2 mt-3"><input aria-label="Ask a question" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&ask(q)} placeholder="Ask about beds, stock, equipment…" className="flex-1 border rounded-lg px-3 py-2 text-sm"/><Btn onClick={()=>ask(q)}><Send size={16}/></Btn></div></Card>;
}
