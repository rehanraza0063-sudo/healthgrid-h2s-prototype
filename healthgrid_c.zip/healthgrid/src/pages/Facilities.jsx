import {useState,useMemo} from 'react';
import {ArrowLeft,Search} from 'lucide-react';
import {LineChart,Line,XAxis,YAxis,Tooltip,ResponsiveContainer,BarChart,Bar,Legend} from 'recharts';
import {Card,RiskBadge,Btn,Progress,Select,Tbl,Synthetic} from '../components/ui';
import FacilityMap from '../components/FacilityMap';
import {NearbyBeds} from '../components/Nearby';
import {facilities,medicines,equipment,alerts} from '../data/mockData';
import {bedStats,avail,find,dist,footfallPct,fac} from '../services/resources';
import {AlertCard} from './Dashboard';

export function FacilityList({ctx}){
  const rows=facilities.filter(f=>!ctx.q||(f.name+f.area+f.type).toLowerCase().includes(ctx.q.toLowerCase()));
  const ref=facilities[0];
  return <Card title="Healthcare Facilities" right={<Synthetic/>}>{rows.length?<Tbl head={['Facility','Type','Area','Population','Beds','Available','Medicine','Equipment','Staff','Risk','Distance']}>
    {rows.map(f=>{const b=bedStats(f);return <tr key={f.id} onClick={()=>ctx.open(f.id)} className="border-b hover:bg-teal-50/50 cursor-pointer">
      <td className="py-2 font-medium whitespace-nowrap">{f.name}</td><td>{f.type}</td><td>{f.area}</td><td>{f.pop.toLocaleString()}</td><td>{b.total}</td><td>{b.avail}</td>
      <td>{f.med}%</td><td>{f.eq}%</td><td>{f.staff}%</td><td><RiskBadge r={f.risk}/></td><td>{f.id===ref.id?'—':dist(ref,f)+' km'}</td></tr>})}</Tbl>
    :<p className="text-center text-slate-400 py-8">No facilities match “{ctx.q}”.</p>}<p className="text-xs text-slate-400 mt-2">Distance measured from {ref.name}.</p></Card>;
}
export function BedRows({f,onFind}){
  return <div className="grid md:grid-cols-2 gap-3">{Object.entries(f.beds).map(([t,[tot,occ]])=>{const a=tot-occ;return (
    <div key={t} className="border rounded-xl p-3 bg-white"><div className="flex justify-between text-sm font-medium"><span>{t}</span><span>{tot?`${occ} / ${tot} occupied`:'Not provided'}</span></div>
      {tot>0&&<div className="my-2"><Progress v={occ} max={tot}/></div>}
      {tot>0&&a===0&&<div className="text-red-600 font-bold text-sm">NO BED AVAILABLE</div>}{tot>0&&a>0&&<div className="text-xs text-slate-500">{a} available</div>}
      {onFind&&tot>0&&<Btn variant={a===0?'danger':'ghost'} className="mt-2" onClick={()=>onFind(t)}>Find Nearby Available Beds</Btn>}</div>)})}</div>;
}
export function FacilityDetail({f,ctx}){
  const [tab,setTab]=useState('Overview'),[near,setNear]=useState(false);
  const b=bedStats(f),reserved=ctx.reservations.filter(r=>r.fid===f.id).length;
  const fa=alerts.filter(a=>a.fid===f.id),resolvedHere=ctx.reservations.some(r=>r.origin===f.id);
  const ms=medicines.filter(m=>m.fid===f.id).sort((a,b)=>a.days-b.days),es=equipment.filter(e=>e.fid===f.id);
  const trend=['Mon','Tue','Wed','Thu','Fri','Sat','Today'].map((d,i)=>({d,patients:i===6?f.today:Math.round(f.avg*(0.85+((i*37)%30)/100))}));
  const S=({l,v})=><div className="bg-slate-50 rounded-xl p-3"><div className="text-xs text-slate-500">{l}</div><div className="font-semibold">{v}</div></div>;
  const emptyType=Object.keys(f.beds).find(t=>f.beds[t][0]>0&&avail(f,t)===0)||'Emergency';
  return <div className="space-y-4">
    <div className="flex items-center gap-3 flex-wrap"><Btn variant="ghost" onClick={()=>ctx.go('facilities')}><ArrowLeft size={14} className="inline"/> Back</Btn>
      <div><h2 className="text-xl font-bold">{f.name}</h2><div className="text-sm text-slate-500">{f.type} • {f.area} • {f.lat.toFixed(3)}, {f.lng.toFixed(3)}</div></div><RiskBadge r={f.risk}/></div>
    {resolvedHere&&<div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-sm text-emerald-800">✅ Emergency bed shortage resolved through nearby facility.</div>}
    <div className="flex gap-1 border-b overflow-x-auto">{['Overview','Beds','Medicines','Equipment','Staff','Patients'].map(t=>
      <button key={t} onClick={()=>setTab(t)} className={`px-3 py-2 text-sm whitespace-nowrap ${tab===t?'border-b-2 border-teal-600 text-teal-700 font-semibold':'text-slate-500'}`}>{t}</button>)}</div>
    {tab==='Overview'&&<><div className="grid grid-cols-2 lg:grid-cols-4 gap-3"><S l="Population served" v={f.pop.toLocaleString()}/><S l="Population density" v={f.dens}/><S l="Today's footfall" v={`${f.today} (${footfallPct(f)>0?'+':''}${footfallPct(f)}%)`}/><S l="Staff attendance" v={f.staff+'%'}/>
      <S l="Beds total / occupied" v={`${b.total} / ${b.occ}`}/><S l="Beds available / reserved" v={`${b.avail} / ${reserved}`}/><S l="Medicine health" v={f.med+'%'}/><S l="Equipment availability" v={f.eq+'%'}/></div>
      <div className="flex gap-2"><Btn onClick={()=>setNear(n=>!n)}>Find Nearby Resources</Btn></div>
      {near&&<NearbyBeds f={f} type={emptyType} ctx={ctx} results={find('Bed',emptyType,f)}/>}
      <div className="grid lg:grid-cols-2 gap-4"><Card title="Location"><FacilityMap items={[f]} height={240}/></Card>
        <Card title="Current alerts">{fa.length?<div className="space-y-2">{fa.map(a=><AlertCard key={a.id} a={a} ctx={ctx} resolved={ctx.resolved(a)}/>)}</div>:<p className="text-sm text-slate-400">No active alerts.</p>}</Card></div></>}
    {tab==='Beds'&&<BedRows f={f} onFind={t=>{ctx.go('beds',f.id,t)}}/>}
    {tab==='Medicines'&&<Card><Tbl head={['Medicine','Stock','Daily','Days left','Risk']}>{ms.map(m=><tr key={m.id} className="border-b"><td className="py-1.5">{m.name} {m.strength}</td><td>{m.stock.toLocaleString()}</td><td>{m.daily}</td><td>{m.days}</td><td><RiskBadge r={m.risk}/></td></tr>)}</Tbl></Card>}
    {tab==='Equipment'&&<Card><Tbl head={['Equipment','Total','Operational','Maintenance','Status']}>{es.map(e=><tr key={e.id} className="border-b"><td className="py-1.5">{e.name}</td><td>{e.total}</td><td>{e.oper}</td><td>{e.maint}</td><td className={e.status==='Unavailable'?'text-red-600 font-semibold':''}>{e.status}</td></tr>)}</Tbl></Card>}
    {tab==='Staff'&&<Card title="Staff availability" right={<Synthetic/>}>{[['Doctors',Math.max(2,Math.round(f.pop/40000))],['Nurses',Math.max(4,Math.round(f.pop/15000))],['Pharmacists',Math.max(1,Math.round(f.pop/90000))],['Lab technicians',Math.max(1,Math.round(f.pop/70000))]].map(([r,n])=>
      <div key={r} className="mb-3"><div className="flex justify-between text-sm"><span>{r}</span><span>{Math.round(n*f.staff/100)} / {n} present</span></div><Progress v={f.staff} tone="bg-teal-500"/></div>)}</Card>}
    {tab==='Patients'&&<Card title="Patient footfall — last 7 days" right={<Synthetic/>}><div style={{height:240}}><ResponsiveContainer><LineChart data={trend}><XAxis dataKey="d"/><YAxis/><Tooltip/><Line dataKey="patients" stroke="#0d9488" strokeWidth={3}/></LineChart></ResponsiveContainer></div></Card>}</div>;
}
export function Beds({ctx,initial}){
  const [id,setId]=useState(initial?.fid||'dharavi'),[type,setType]=useState(initial?.type||null);
  const f=fac(id),b=bedStats(f),em=f.beds.Emergency;
  const chart=facilities.map(x=>({name:x.name.replace('PHC ','').replace('Community Health Centre','CHC').replace('District Hospital','DH'),Occupied:bedStats(x).occ,Available:bedStats(x).avail}));
  const S=({l,v})=><div className="bg-white rounded-xl border p-3"><div className="text-xs text-slate-500">{l}</div><div className="text-xl font-bold">{v}</div></div>;
  return <div className="space-y-4"><Card title="Bed Availability" right={<Select label="Facility" value={id} onChange={v=>{setId(v);setType(null)}} options={facilities.map(x=>[x.id,x.name])}/>}>
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4"><S l="Total beds" v={b.total}/><S l="Occupied" v={b.occ}/><S l="Available" v={b.avail}/><S l="Reserved (simulated)" v={ctx.reservations.filter(r=>r.fid===id).length}/><S l="Emergency beds" v={`${em[0]-em[1]} / ${em[0]}`}/></div>
    <BedRows f={f} onFind={setType}/></Card>
    {type&&<NearbyBeds f={f} type={type} ctx={ctx} results={find('Bed',type,f)}/>}
    <Card title="Bed occupancy across the network"><div style={{height:260}}><ResponsiveContainer><BarChart data={chart}><XAxis dataKey="name" tick={{fontSize:10}} interval={0} angle={-25} height={60} textAnchor="end"/><YAxis/><Tooltip/><Legend/><Bar dataKey="Occupied" stackId="a" fill="#f97316"/><Bar dataKey="Available" stackId="a" fill="#14b8a6"/></BarChart></ResponsiveContainer></div></Card>
    <Card title="Simulated reservations" right={ctx.reservations.length>0&&<Btn variant="ghost" onClick={ctx.clearRes}>Clear</Btn>}>
      {ctx.reservations.length?<Tbl head={['ID','Facility','Bed','Patient Ref','Status']}>{ctx.reservations.map(r=><tr key={r.id} className="border-b"><td className="py-1.5 font-mono">{r.id}</td><td>{fac(r.fid).name}</td><td>{r.bed}</td><td>{r.ref}</td><td>{r.status}</td></tr>)}</Tbl>
      :<p className="text-sm text-slate-400">No reservations yet. Prototype simulation — not a real medical booking.</p>}</Card></div>;
}
