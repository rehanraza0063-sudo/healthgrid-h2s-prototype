import {useState} from 'react';
import {Search} from 'lucide-react';
import {Card,Btn,Select,Synthetic} from '../components/ui';
import {ResultCards} from '../components/Nearby';
import FacilityMap from '../components/FacilityMap';
import {facilities,medicines} from '../data/mockData';
import {CATALOG,find,fac,recommendTransfer} from '../services/resources';
import {TransferCard} from './Inventory';

export default function Network({ctx}){
  const [kind,setKind]=useState('Equipment'),[item,setItem]=useState('Ventilator'),[from,setFrom]=useState('dharavi'),[res,setRes]=useState(null);
  const run=()=>setRes(find(kind,item,fac(from)));
  const t=recommendTransfer(fac('dharavi'),'Amoxicillin');
  const origin=fac(from),shown=res?res.slice(0,5):[];
  return <div className="space-y-4">
    <Card title="Find a Resource" right={<Synthetic/>} className="border-teal-300">
      <div className="flex flex-wrap gap-2 items-end">
        <Select label="Resource type" value={kind} onChange={k=>{setKind(k);setItem(CATALOG[k][0]);setRes(null)}} options={Object.keys(CATALOG)}/>
        <Select label="Resource" value={item} onChange={v=>{setItem(v);setRes(null)}} options={CATALOG[kind]}/>
        <Select label="Searching from" value={from} onChange={v=>{setFrom(v);setRes(null)}} options={facilities.map(f=>[f.id,f.name])}/>
        <Btn onClick={run}><Search size={14} className="inline mr-1"/>Find Nearby</Btn></div>
      {res&&<div className="grid lg:grid-cols-2 gap-4 mt-4"><ResultCards results={shown} onView={ctx.open}
        action={r=>kind==='Bed'?<Btn onClick={()=>ctx.book({fid:r.f.id,type:item,origin:from})}>Reserve Bed</Btn>:<Btn variant="ghost" onClick={()=>ctx.open(r.f.id)}>View</Btn>}/>
        <FacilityMap items={[origin,...shown.map(r=>r.f)]} focus={[origin.id,...shown.map(r=>r.f.id)]} height={300} onOpen={ctx.open}/></div>}
      {!res&&<p className="text-sm text-slate-400 mt-3">Choose a resource and search across all demo facilities.</p>}</Card>
    <Card title="Resource Network Flow — Scenario 1: Bed shortage" right={<Synthetic/>}>
      <div className="flex flex-col items-center text-sm gap-1">{['❌ PHC Dharavi — no emergency bed','↓ HealthGrid searches nearby facilities','PHC Kurla — 1.8 km','↓ 4 emergency beds available'].map((s,i)=><div key={i} className={s.startsWith('↓')?'text-slate-400':'font-semibold bg-slate-50 rounded-lg px-4 py-2'}>{s}</div>)}
        <Btn onClick={()=>ctx.book({fid:'kurla',type:'Emergency',origin:'dharavi'})}>Reserve / Navigate</Btn></div></Card>
    <div><h3 className="font-semibold mb-2">Scenario 2: Medicine redistribution</h3>{t&&<TransferCard t={t} ctx={ctx}/>}</div></div>;
}
