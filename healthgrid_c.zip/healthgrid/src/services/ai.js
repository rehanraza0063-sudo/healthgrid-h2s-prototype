// Rule-based "HealthGrid Intelligence" over SYNTHETIC data. Swap for Gemini later (see README).
import {facilities,medicines} from '../data/mockData';
import {find,fac,avail,recommendTransfer,footfallPct,oxy} from './resources';
const D=()=>fac('dharavi');
export const SUGGESTED=['Which PHCs currently have bed shortages?','Where can I find an available ventilator?','Which medicines are at highest shortage risk?',
'Which nearby PHC has emergency beds?','Which facility has the highest patient footfall?','Why is PHC Dharavi marked as high risk?','Where should we redistribute Amoxicillin?','Why was this facility selected?'];
const list=(rs)=>rs.map((r,i)=>`${i+1}. ${r.f.name}\n   ${r.km} km • ETA ${r.eta} min • ${r.detail}`).join('\n');
export function answer(q){
  const s=q.toLowerCase();
  if(s.includes('why was')||s.includes('selected')){
    const b=find('Bed','Emergency',D()).find(r=>r.ok),t=recommendTransfer(D(),'Amoxicillin');
    return `${b.f.name} was selected for emergency beds because:\n• Distance: ${b.km} km (nearest facility with capacity), ETA ${b.eta} min\n• Availability: ${b.count} emergency beds free, ${oxy(b.f)} oxygen concentrators operational\n• Demand: PHC Dharavi has ${D().today} patients today vs ${D().avg} usual (${footfallPct(D())>0?'+':''}${footfallPct(D())}%)\n• Stock: ${b.f.name} medicine health is ${b.f.med}%\n\nFor Amoxicillin, ${t.from.name} was chosen: ${t.reason} Recommended transfer: ${t.units} units.`;}
  if(s.includes('bed')&&(s.includes('shortage')||s.includes('which phc'))){
    const r=facilities.filter(f=>avail(f,'Emergency')===0||avail(f,'General')<=1);
    return `${r.length} facilities have critical bed shortages:\n`+r.map(f=>`• ${f.name} — emergency ${avail(f,'Emergency')} free, general ${avail(f,'General')} free`).join('\n');}
  if(s.includes('ventilator')){const r=find('Equipment','Ventilator',D()).filter(x=>x.ok).slice(0,3);return `Nearest operational ventilators from PHC Dharavi:\n${list(r)}`;}
  if(s.includes('emergency bed')||s.includes('options')){const r=find('Bed','Emergency',D()).filter(x=>x.ok).slice(0,3);
    return `${r.length} nearby facilities currently show emergency bed availability:\n\n${list(r)}\n\nYou can open the facility details or simulate a reservation.`;}
  if(s.includes('medicine')&&(s.includes('risk')||s.includes('shortage'))){const r=[...medicines].sort((a,b)=>a.days-b.days).slice(0,5);
    return 'Highest shortage risk:\n'+r.map(m=>`• ${m.name} at ${fac(m.fid).name} — ${m.days} days left (${m.risk})`).join('\n');}
  if(s.includes('footfall')){const f=[...facilities].sort((a,b)=>b.today/b.avg-a.today/a.avg)[0],big=[...facilities].sort((a,b)=>b.today-a.today)[0];
    return `Highest absolute footfall: ${big.name} (${big.today} patients).\nBiggest surge vs normal: ${f.name} (${f.today} vs ${f.avg} avg, +${footfallPct(f)}%).`;}
  if(s.includes('dharavi')&&(s.includes('risk')||s.includes('why'))){const d=D();
    return `PHC Dharavi is ${d.risk} risk because:\n• Emergency beds 4/4 occupied\n• Footfall ${d.today} vs ${d.avg} avg (+${footfallPct(d)}%), very high density (${d.pop.toLocaleString()} people served)\n• Amoxicillin has only 2.4 days of stock\n• Defibrillator under maintenance, staff attendance ${d.staff}%`;}
  if(s.includes('redistribut')||s.includes('amoxicillin')||s.includes('transfer')){const t=recommendTransfer(D(),'Amoxicillin');return `Recommended: move ${t.units} units of Amoxicillin from ${t.from.name} → ${t.to.name}.\n${t.reason}`;}
  return 'I can answer questions about beds, medicines, equipment, footfall and redistribution in the demo dataset. Try one of the suggested questions.';
}
