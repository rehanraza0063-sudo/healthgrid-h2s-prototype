import {facilities,medicines,equipment} from '../data/mockData';
export const fac=id=>facilities.find(f=>f.id===id);
export const dist=(a,b)=>{const r=x=>x*Math.PI/180,R=6371,dLa=r(b.lat-a.lat),dLo=r(b.lng-a.lng);
  const h=Math.sin(dLa/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(dLo/2)**2;return +(2*R*Math.asin(Math.sqrt(h))*1.3).toFixed(1)};
export const eta=d=>Math.round(d*4+3);
export const avail=(f,t)=>f.beds[t][0]-f.beds[t][1];
export const bedStats=f=>{const v=Object.values(f.beds);const total=v.reduce((a,b)=>a+b[0],0),occ=v.reduce((a,b)=>a+b[1],0);return {total,occ,avail:total-occ}};
export const oxy=f=>equipment.find(e=>e.fid===f.id&&e.name==='Oxygen Concentrator')?.oper||0;
export const CATALOG={Bed:['Emergency','General','Pediatric','Maternity','ICU'],Medicine:[...new Set(medicines.map(m=>m.name))],
  Equipment:[...new Set(equipment.map(e=>e.name))],Specialist:['Cardiologist','Pediatrician','Gynecologist','Pulmonologist'],
  Blood:['O+','A+','B+','O-'],'Emergency resource':['Ambulance','Oxygen Cylinders','Trauma Kit']};
const synth=(f,item)=>{const fi=facilities.indexOf(f);let h=0;for(const c of item)h=(h*31+c.charCodeAt(0))%97;return Math.max(0,((fi*7+h)%6)-1+(f.type==='PHC'?0:2))};
export function find(kind,item,from){
  return facilities.filter(f=>f.id!==from.id).map(f=>{
    let count,detail;
    if(kind==='Bed'){count=avail(f,item);detail=`${item} beds: ${count} available`}
    else if(kind==='Medicine'){const m=medicines.find(x=>x.fid===f.id&&x.name===item);if(!m)return null;count=m.days>=8?m.stock:0;detail=`${m.stock.toLocaleString()} units • ${m.days} days of stock`}
    else if(kind==='Equipment'){const e=equipment.find(x=>x.fid===f.id&&x.name===item);if(!e)return null;count=e.oper;detail=`${e.oper}/${e.total} operational${e.maint?` • ${e.maint} in maintenance`:''}`}
    else{count=synth(f,item);detail=`${count} available (demo)`}
    const km=dist(from,f);return {f,km,eta:eta(km),count,detail,ok:count>0};
  }).filter(Boolean).sort((a,b)=>b.ok-a.ok||a.km-b.km);
}
export function recommendTransfer(toF,name){
  const to=medicines.find(m=>m.fid===toF.id&&m.name===name);if(!to)return null;
  const donors=medicines.filter(m=>m.name===name&&m.fid!==toF.id&&m.days>=12).map(m=>({m,km:dist(toF,fac(m.fid))})).sort((a,b)=>a.km-b.km);
  if(!donors.length)return null;const {m,km}=donors[0];const from=fac(m.fid);
  const units=Math.min(200,Math.floor(m.stock*0.3));
  return {from,to:toF,name,units,km,donorDays:m.days,targetDays:to.days,
    reason:`${toF.name} has high patient demand (${toF.today} patients today vs ${toF.avg} avg) and about ${to.days} days of ${name} left, while ${from.name} holds ${m.days} days of stock and is ${km} km away.`};
}
export const footfallPct=f=>Math.round((f.today/f.avg-1)*100);
